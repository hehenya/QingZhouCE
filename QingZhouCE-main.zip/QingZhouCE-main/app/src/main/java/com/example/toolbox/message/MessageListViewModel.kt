package com.example.toolbox.message

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.toolbox.ApiAddress
import com.example.toolbox.AppJson
import com.example.toolbox.data.ChatItem
import com.example.toolbox.data.ChatListResponse
import com.example.toolbox.data.FriendsListRequest
import com.example.toolbox.data.MessageUiState
import com.example.toolbox.data.Pagination
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

class MessageViewModel(
    private val token: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(MessageUiState())
    val uiState: StateFlow<MessageUiState> = _uiState.asStateFlow()

    private val client = OkHttpClient()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private var isWebSocketUpdate = false

    private val messageObserver: (type: String, message: ChatItem) -> Unit = { type, _ ->
        when (type) {
            "new", "edit", "recall" -> {
                isWebSocketUpdate = true
                silentRefresh()
            }
        }
    }

    init {
        loadFriends(page = 1, isRefresh = true)
    }

    private fun silentRefresh() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(error = null)
            }

            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val json = AppJson.json.encodeToString(
                        FriendsListRequest.serializer(),
                        FriendsListRequest(page = 1, per_page = 20)
                    )
                    val requestBody = json.toRequestBody(jsonMediaType)
                    val request = Request.Builder()
                        .url("${ApiAddress}chat/list")
                        .post(requestBody)
                        .header("x-access-token", token)
                        .build()
                    val response = client.newCall(request).execute()
                    if (!response.isSuccessful) {
                        return@withContext null
                    }
                    val responseBody = response.body?.string() ?: return@withContext null
                    AppJson.json.decodeFromString<ChatListResponse>(responseBody)
                }
            }

            result.onSuccess { chatListResponse ->
                if (chatListResponse != null && chatListResponse.success) {
                    _uiState.update { current ->
                        current.copy(
                            chats = chatListResponse.friends,
                            pagination = chatListResponse.pagination,
                            hasMore = chatListResponse.pagination.currentPage < chatListResponse.pagination.pages,
                            error = null
                        )
                    }
                }
            }

            isWebSocketUpdate = false
        }
    }

    fun refresh() {
        if (isWebSocketUpdate) {
            isWebSocketUpdate = false
            return
        }
        loadFriends(page = 1, isRefresh = true)
    }

    fun loadMore() {
        val currentState = _uiState.value
        if (currentState.isLoadingMore || !currentState.hasMore) return
        val nextPage = (currentState.pagination?.currentPage ?: 0) + 1
        loadFriends(page = nextPage, isRefresh = false)
    }

    private fun loadFriends(page: Int, isRefresh: Boolean) {
        viewModelScope.launch {
            _uiState.update {
                if (isRefresh) it.copy(isRefreshing = true, error = null)
                else it.copy(isLoadingMore = true, error = null)
            }

            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val json = AppJson.json.encodeToString(
                        FriendsListRequest.serializer(),
                        FriendsListRequest(page = page, per_page = 20)
                    )
                    val requestBody = json.toRequestBody(jsonMediaType)
                    val request = Request.Builder()
                        .url("${ApiAddress}friends/list")
                        .post(requestBody)
                        .header("x-access-token", token)
                        .build()
                    val response = client.newCall(request).execute()
                    if (!response.isSuccessful) {
                        return@withContext null
                    }
                    val responseBody = response.body?.string() ?: return@withContext null
                    AppJson.json.decodeFromString<ChatListResponse>(responseBody)
                }
            }

            result.onSuccess { chatListResponse ->
                if (chatListResponse != null && chatListResponse.success) {
                    _uiState.update { current ->
                        val newChats = if (isRefresh) chatListResponse.friends
                        else current.chats + chatListResponse.friends
                        current.copy(
                            chats = newChats,
                            pagination = chatListResponse.pagination,
                            hasMore = chatListResponse.pagination.currentPage < chatListResponse.pagination.pages,
                            isRefreshing = false,
                            isLoadingMore = false,
                            error = null
                        )
                    }
                } else {
                    _uiState.update { it.copy(
                        isRefreshing = false,
                        isLoadingMore = false,
                        error = "请求失败或数据为空"
                    ) }
                }
            }.onFailure { e ->
                _uiState.update { it.copy(
                    isRefreshing = false,
                    isLoadingMore = false,
                    error = e.message
                ) }
            }
        }
    }

    fun connectWebSocket() {
        if (token.isNotBlank()) {
            val manager = PrivateChatSocketManager.getInstance()
            manager.addObserver(messageObserver)
            manager.connect(token)
        }
    }

    fun disconnectWebSocket() {
        val manager = PrivateChatSocketManager.getInstance()
        manager.removeObserver(messageObserver)
    }

    override fun onCleared() {
        super.onCleared()
        disconnectWebSocket()
    }
}

class MessageViewModelFactory(private val token: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MessageViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MessageViewModel(token) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}